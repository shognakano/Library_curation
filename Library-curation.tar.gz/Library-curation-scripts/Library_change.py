import os,sys,re
from numpy import *

inputname = [];input_data = [];final_data = []

while len(sys.argv)>1:
	option = sys.argv[1]
	del sys.argv[1]
	if option == '-INPUT':
		inputname = str(sys.argv[1])
		del sys.argv[1]
	elif option == '-OUTPUT':
		outputfile = str(sys.argv[1])
		del sys.argv[1]

input_data = (file(inputname).read()).split('\n')
#print len(input_data)

for i in range(len(input_data)):
	data1 = [];flag = int(0)
	data1 = input_data[i]
	if re.search(r'''>.*''',data1):
		#print data1
		flag = int(1)

	if flag == int(1):
		data2 = []
		data2 = re.split(r'''\s+''',data1)[0]
		if i==0:
			final_data.append(data2)
			final_data.append('\n')
			continue
		final_data.append('\n')
		final_data.append(data2)
		final_data.append('\n')
	else:
		final_data.append(data1)
		final_data.append('\n')

out_file = open(outputfile,'w')
for j in range(len(final_data)):
	output_column = []
	output_column = final_data[j]
	out_file.write("%(output_column)s"%vars())
out_file.close()

 
