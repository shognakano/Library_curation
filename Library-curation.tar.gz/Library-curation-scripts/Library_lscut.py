##############################
#Sub routine
##############################

def NULLELIM(cvs):
	aft_data = []
	for i in range(len(cvs)):
		temp = []
		temp = cvs[i]
		if re.search('.*\w+.*',temp):
			aft_data.append(temp)
		else:
			continue
	return aft_data

def SEQRET(input_stp):
	input_stp = NULLELIM(input_stp);ret_inputstp = []
	for i in range(len(input_stp)):
		tmp = []
		tmp = input_stp[i]
		if re.search(">.*",tmp):
			continue
		else:
			ret_inputstp.append(tmp)
	ret_inputstp = ''.join(ret_inputstp)
	return ret_inputstp

def DELFLAG(input_seqnum,library_data,cutper):
	library_del_array = [];cutmax = float(0);cutmin = float(0)
	cutmax = input_seqnum + input_seqnum*cutper
	cutmin = input_seqnum - input_seqnum*cutper
	print cutmin
	print cutmax
	for i in range(len(library_data)):
		tmp_lib = [];tmp_lib_num = int(0)
		tmp_lib = library_data[i]
		tmp_lib = tmp_lib.split("\n")
		tmp_lib = NULLELIM(tmp_lib)
		tmp_lib = SEQRET(tmp_lib)
		tmp_lib_num = len(tmp_lib)
		
		#print cutmin
		#print cutmax

		if cutmin < tmp_lib_num < cutmax:
			continue
		else:
			library_del_array.insert(0,str(i))
	return library_del_array

##############################
#Main program
##############################		

import os,sys,re,random
import numpy as np

while len(sys.argv) > 1:
	option = sys.argv[1]
	del sys.argv[1]
	if option == "-INPUTSTP":
		inputstp = sys.argv[1]
		del sys.argv[1]
	elif option == "-INPUTLIB":
		inputlib = sys.argv[1]
		del sys.argv[1]
	elif option == "-CUTPER":
		cutper = float(sys.argv[1])
		del sys.argv[1]
	elif option == "-OUTPUT":
		output = sys.argv[1]
		del sys.argv[1]

input_seqnum = int(0)
input_stp = file(inputstp).read().split("\n")

input_stp1 = SEQRET(input_stp)
input_seqnum = len(input_stp1)

library_data = file(inputlib).read().split("\n\n")
library_del_array = DELFLAG(input_seqnum,library_data,cutper)

for i in range(len(library_del_array)):
	tmp_delnum = int(0)
	tmp_delnum = int(library_del_array[i])
	del library_data[tmp_delnum]

delnum = len(library_del_array)
num_of_seqs = len(library_data)-int(1)

print "#Number of Deleted sequences are: %(delnum)i"%vars()
print "#Total number of sequences in %(output)s are: %(num_of_seqs)i"%vars()

outputfile = open(output,"w")
for j in range(len(library_data)):
	tmp_data = []
	tmp_data = library_data[j]
	outputfile.write("%(tmp_data)s\n\n"%vars())


