#!/xtal/Python-2.6.7/bin/python
#This program deletes a code "\r". The code will induce error in roseta process.
import os,sys,re
import numpy as np

while len(sys.argv) > 1:
	option = sys.argv[1]
	del sys.argv[1]
	if option == "-INPUT":
		inputfile = sys.argv[1]
		del sys.argv[1]

data = []
last_data = []
data = (file(inputfile).read()).split('\n')

for i in range(len(data)):
	data2 = [];data3 = []
	data2 = data[i]
	if re.search(r'''\r''',data2):
		data3 = re.split("\r",data2)
		data3 = "".join(data3)
	else:
		data3 = data2
	last_data.append(data3)	

outputfile = open(inputfile,"w")

for j in range(len(last_data)):
	wrt_data = []
	wrt_data = last_data[j]
	outputfile.write("%(wrt_data)s\n"%vars())




